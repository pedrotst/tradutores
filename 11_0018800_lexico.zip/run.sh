lex sint.lex 
gcc -o sint.out lex.yy.c -lfl 
./sint.out
